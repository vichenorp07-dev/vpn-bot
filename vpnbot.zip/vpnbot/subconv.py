"""Конвертер подписок: обычная подписка 3x-ui (base64 со ссылками vless:// и т.п.)
-> форматы для разных приложений.

Поддерживаемые форматы:
  raw     — ссылки vless:// построчно (обычный текст)
  b64     — то же в base64 (Happ, v2rayNG, v2rayN, Streisand, Hiddify, Shadowrocket…)
  clash   — YAML для Clash Meta / Mihomo (Clash Verge Rev, FlClash, Clash Meta for Android)
  singbox — JSON для sing-box (SFI, SFA, SFM, Karing)
  xray    — JSON-массив полных конфигов Xray (v2rayN, v2rayNG, Happ, Streisand)

Только стандартная библиотека Python.
"""

import base64
import json
from urllib.parse import parse_qs, unquote, urlparse

LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "0.0.0.0", ""}


class Node(dict):
    """Один сервер из подписки. Ключи: proto, name, server, port, uuid/password, ..."""


# ====================== разбор ссылок ======================


def decode_subscription(body: str) -> list[str]:
    """Тело подписки (base64 или обычный текст) -> список ссылок."""
    text = body.strip()
    if "://" not in text:
        try:
            text = base64.b64decode(text + "=" * (-len(text) % 4)).decode("utf-8", "replace")
        except Exception:
            return []
    return [line.strip() for line in text.splitlines() if "://" in line]


def _q(params: dict, key: str, default: str = "") -> str:
    v = params.get(key)
    return v[0] if v else default


def parse_link(link: str, public_host: str = "") -> Node | None:
    """Ссылка vless/vmess/trojan/ss -> Node. Неизвестное -> None."""
    scheme = link.split("://", 1)[0].lower()
    try:
        if scheme == "vmess":
            node = _parse_vmess(link)
        elif scheme in ("vless", "trojan"):
            node = _parse_vless_trojan(link, scheme)
        elif scheme == "ss":
            node = _parse_ss(link)
        else:
            return None
    except Exception:
        return None
    if node is None:
        return None
    # Подписку бот скачивает с самого сервера, и панель может подставить localhost
    if public_host and node["server"] in LOCAL_HOSTS:
        node["server"] = public_host
    node["link"] = link
    return node


def _parse_vless_trojan(link: str, proto: str) -> Node:
    u = urlparse(link)
    p = parse_qs(u.query)
    n = Node(
        proto=proto,
        name=unquote(u.fragment) or f"{proto}-{u.hostname}",
        server=u.hostname or "",
        port=int(u.port or 443),
        network=_q(p, "type", "tcp"),
        security=_q(p, "security", "none"),
        sni=_q(p, "sni") or _q(p, "peer"),
        fp=_q(p, "fp"),
        alpn=[a for a in _q(p, "alpn").split(",") if a],
        pbk=_q(p, "pbk"),
        sid=_q(p, "sid"),
        spx=_q(p, "spx"),
        flow=_q(p, "flow"),
        path=_q(p, "path"),
        host=_q(p, "host"),
        service_name=_q(p, "serviceName"),
        mode=_q(p, "mode"),
        insecure=_q(p, "allowInsecure") in ("1", "true"),
    )
    user = unquote(u.username or "")
    if proto == "vless":
        n["uuid"] = user
        n["encryption"] = _q(p, "encryption", "none")
    else:
        n["password"] = user
    return n


def _parse_vmess(link: str) -> Node:
    raw = link.split("://", 1)[1]
    data = json.loads(base64.b64decode(raw + "=" * (-len(raw) % 4)).decode())
    return Node(
        proto="vmess",
        name=data.get("ps") or f"vmess-{data.get('add')}",
        server=data.get("add", ""),
        port=int(data.get("port") or 443),
        uuid=data.get("id", ""),
        alter_id=int(data.get("aid") or 0),
        cipher=data.get("scy") or "auto",
        network=data.get("net") or "tcp",
        security="tls" if data.get("tls") == "tls" else "none",
        sni=data.get("sni", ""),
        fp=data.get("fp", ""),
        alpn=[a for a in (data.get("alpn") or "").split(",") if a],
        path=data.get("path", ""),
        host=data.get("host", ""),
        service_name=data.get("path", "") if data.get("net") == "grpc" else "",
        pbk="", sid="", spx="", flow="", mode="", insecure=False,
    )


def _parse_ss(link: str) -> Node | None:
    u = urlparse(link)
    if u.username and u.hostname:  # SIP002: ss://base64(method:pass)@host:port
        userinfo = unquote(u.username)
        if ":" not in userinfo:
            userinfo = base64.urlsafe_b64decode(userinfo + "=" * (-len(userinfo) % 4)).decode()
        method, password = userinfo.split(":", 1)
        server, port = u.hostname, u.port
    else:  # старый формат: ss://base64(method:pass@host:port)
        raw = link.split("://", 1)[1].split("#", 1)[0]
        decoded = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)).decode()
        creds, hostport = decoded.rsplit("@", 1)
        method, password = creds.split(":", 1)
        server, port = hostport.rsplit(":", 1)
    return Node(proto="ss", name=unquote(u.fragment) or f"ss-{server}", server=server,
                port=int(port), cipher=method, password=password, network="tcp", security="none")


def parse_subscription(body: str, public_host: str = "") -> list[Node]:
    nodes = [parse_link(link, public_host) for link in decode_subscription(body)]
    nodes = [n for n in nodes if n]
    # Имена должны быть уникальными (Clash и sing-box этого требуют)
    seen: dict[str, int] = {}
    for n in nodes:
        base = n["name"]
        if base in seen:
            seen[base] += 1
            n["name"] = f"{base} {seen[base]}"
        else:
            seen[base] = 1
    return nodes


# ====================== raw / base64 ======================


def to_raw(nodes: list[Node]) -> str:
    links = []
    for n in nodes:
        link = n["link"]
        if n["server"] and "@localhost:" in link:
            link = link.replace("@localhost:", f"@{n['server']}:")
        links.append(link)
    return "\n".join(links) + "\n"


def to_base64(nodes: list[Node]) -> str:
    return base64.b64encode(to_raw(nodes).encode()).decode()


# ====================== Clash Meta / Mihomo ======================


def _clash_proxy(n: Node) -> dict | None:
    net = n["network"]
    if net in ("xhttp", "splithttp", "kcp", "quic"):
        return None  # Mihomo такие транспорты не поддерживает
    p: dict = {"name": n["name"], "server": n["server"], "port": n["port"], "udp": True}
    if n["proto"] == "ss":
        p.update(type="ss", cipher=n["cipher"], password=n["password"])
        return p
    if n["proto"] == "vless":
        p.update(type="vless", uuid=n["uuid"])
        if n["flow"]:
            p["flow"] = n["flow"]
    elif n["proto"] == "vmess":
        p.update(type="vmess", uuid=n["uuid"], alterId=n["alter_id"], cipher=n["cipher"])
    elif n["proto"] == "trojan":
        p.update(type="trojan", password=n["password"])

    p["network"] = "tcp" if net in ("tcp", "raw") else net
    if n["security"] in ("tls", "reality"):
        if n["proto"] != "trojan":
            p["tls"] = True
        if n["sni"]:
            p["sni" if n["proto"] == "trojan" else "servername"] = n["sni"]
        if n["fp"]:
            p["client-fingerprint"] = n["fp"]
        if n["alpn"]:
            p["alpn"] = n["alpn"]
        if n["insecure"]:
            p["skip-cert-verify"] = True
    if n["security"] == "reality":
        p["reality-opts"] = {"public-key": n["pbk"], "short-id": n["sid"]}
        p.setdefault("client-fingerprint", "chrome")
    if net == "ws":
        opts: dict = {"path": n["path"] or "/"}
        if n["host"]:
            opts["headers"] = {"Host": n["host"]}
        p["ws-opts"] = opts
    elif net == "grpc":
        p["grpc-opts"] = {"grpc-service-name": n["service_name"]}
    elif net == "httpupgrade":
        p["network"] = "ws"
        p["ws-opts"] = {"path": n["path"] or "/", "v2ray-http-upgrade": True}
        if n["host"]:
            p["ws-opts"]["headers"] = {"Host": n["host"]}
    return p


PRIVATE_NETS = ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "169.254.0.0/16"]


def to_clash(nodes: list[Node], group: str = "VPN") -> str:
    proxies = [p for p in (_clash_proxy(n) for n in nodes) if p]
    names = [p["name"] for p in proxies]
    cfg = {
        "mixed-port": 7890,
        "allow-lan": False,
        "mode": "rule",
        "log-level": "warning",
        "ipv6": False,
        "dns": {
            "enable": True,
            "ipv6": False,
            "enhanced-mode": "fake-ip",
            "nameserver": ["https://1.1.1.1/dns-query", "https://8.8.8.8/dns-query"],
            "proxy-server-nameserver": ["https://1.1.1.1/dns-query"],
        },
        "proxies": proxies,
        "proxy-groups": [{"name": group, "type": "select", "proxies": names or ["DIRECT"]}],
        "rules": [f"IP-CIDR,{net},DIRECT,no-resolve" for net in PRIVATE_NETS] + [f"MATCH,{group}"],
    }
    return dump_yaml(cfg)


def dump_yaml(obj, indent: int = 0) -> str:
    """Минимальный YAML-писатель: строки в двойных кавычках (как JSON), числа/bool как есть."""
    pad = "  " * indent
    lines: list[str] = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = _yaml_key(k)
            if isinstance(v, (dict, list)) and v:
                lines.append(f"{pad}{key}:")
                lines.append(dump_yaml(v, indent + 1))
            else:
                lines.append(f"{pad}{key}: {_yaml_scalar(v)}")
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, dict) and item:
                inner = dump_yaml(item, indent + 1).splitlines()
                lines.append(f"{pad}- {inner[0].lstrip()}")
                lines.extend(inner[1:])
            elif isinstance(item, list) and item:
                lines.append(f"{pad}-")
                lines.append(dump_yaml(item, indent + 1))
            else:
                lines.append(f"{pad}- {_yaml_scalar(item)}")
    return "\n".join(lines) + ("\n" if indent == 0 else "")


def _yaml_key(k) -> str:
    s = str(k)
    return s if s.replace("-", "").replace("_", "").isalnum() and s.isascii() else json.dumps(s)


def _yaml_scalar(v) -> str:
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, dict):
        return "{}"
    if isinstance(v, list):
        return "[]"
    return json.dumps(str(v), ensure_ascii=False)


# ====================== sing-box ======================


def _singbox_outbound(n: Node) -> dict | None:
    net = n["network"]
    if net in ("xhttp", "splithttp", "kcp"):
        return None  # sing-box такие транспорты не поддерживает
    o: dict = {"tag": n["name"], "server": n["server"], "server_port": n["port"]}
    if n["proto"] == "ss":
        o.update(type="shadowsocks", method=n["cipher"], password=n["password"])
        return o
    if n["proto"] == "vless":
        o.update(type="vless", uuid=n["uuid"], packet_encoding="xudp")
        if n["flow"]:
            o["flow"] = n["flow"]
    elif n["proto"] == "vmess":
        o.update(type="vmess", uuid=n["uuid"], alter_id=n["alter_id"], security=n["cipher"])
    elif n["proto"] == "trojan":
        o.update(type="trojan", password=n["password"])

    if n["security"] in ("tls", "reality"):
        tls: dict = {"enabled": True}
        if n["sni"]:
            tls["server_name"] = n["sni"]
        if n["alpn"]:
            tls["alpn"] = n["alpn"]
        if n["insecure"]:
            tls["insecure"] = True
        fp = n["fp"] or ("chrome" if n["security"] == "reality" else "")
        if fp:
            tls["utls"] = {"enabled": True, "fingerprint": fp}
        if n["security"] == "reality":
            tls["reality"] = {"enabled": True, "public_key": n["pbk"], "short_id": n["sid"]}
        o["tls"] = tls

    if net == "ws":
        t: dict = {"type": "ws", "path": n["path"] or "/"}
        if n["host"]:
            t["headers"] = {"Host": n["host"]}
        o["transport"] = t
    elif net == "grpc":
        o["transport"] = {"type": "grpc", "service_name": n["service_name"]}
    elif net == "httpupgrade":
        o["transport"] = {"type": "httpupgrade", "path": n["path"] or "/", "host": n["host"]}
    elif net == "http":
        o["transport"] = {"type": "http", "path": n["path"] or "/"}
    return o


def to_singbox(nodes: list[Node], group: str = "VPN") -> str:
    outs = [o for o in (_singbox_outbound(n) for n in nodes) if o]
    tags = [o["tag"] for o in outs]
    selector_list = (["auto"] + tags) if len(tags) > 1 else tags
    groups: list[dict] = [{"type": "selector", "tag": group, "outbounds": selector_list or ["direct"]}]
    if len(tags) > 1:
        groups.append({"type": "urltest", "tag": "auto", "outbounds": tags,
                       "url": "https://www.gstatic.com/generate_204", "interval": "5m"})
    cfg = {
        "log": {"level": "warn"},
        "dns": {
            "servers": [
                {"type": "https", "tag": "remote", "server": "1.1.1.1", "detour": group},
                {"type": "local", "tag": "local"},
            ],
            "final": "remote",
            "strategy": "ipv4_only",
        },
        "inbounds": [{
            "type": "tun",
            "tag": "tun-in",
            "address": ["172.19.0.1/30"],
            "auto_route": True,
            "strict_route": True,  # весь трафик только через VPN (защита от утечек)
            "stack": "mixed",
        }],
        "outbounds": groups + outs + [{"type": "direct", "tag": "direct"}],
        "route": {
            "rules": [
                {"action": "sniff"},
                {"protocol": "dns", "action": "hijack-dns"},
                {"ip_is_private": True, "outbound": "direct"},
            ],
            "final": group,
            "auto_detect_interface": True,
            "default_domain_resolver": "local",
        },
    }
    return json.dumps(cfg, ensure_ascii=False, indent=2)


# ====================== Xray JSON ======================


def _xray_outbound(n: Node) -> dict:
    if n["proto"] == "ss":
        return {"tag": "proxy", "protocol": "shadowsocks", "settings": {"servers": [
            {"address": n["server"], "port": n["port"], "method": n["cipher"], "password": n["password"]}]}}
    if n["proto"] == "trojan":
        settings = {"servers": [{"address": n["server"], "port": n["port"], "password": n["password"]}]}
    else:
        user = {"id": n["uuid"]}
        if n["proto"] == "vless":
            user["encryption"] = n.get("encryption") or "none"
            if n["flow"]:
                user["flow"] = n["flow"]
        else:
            user.update(alterId=n["alter_id"], security=n["cipher"])
        settings = {"vnext": [{"address": n["server"], "port": n["port"], "users": [user]}]}

    net = "raw" if n["network"] == "tcp" else n["network"]
    stream: dict = {"network": net, "security": n["security"]}
    if n["security"] == "reality":
        stream["realitySettings"] = {"serverName": n["sni"], "fingerprint": n["fp"] or "chrome",
                                     "publicKey": n["pbk"], "shortId": n["sid"], "spiderX": n["spx"] or "/"}
    elif n["security"] == "tls":
        tls = {"serverName": n["sni"], "allowInsecure": n["insecure"]}
        if n["fp"]:
            tls["fingerprint"] = n["fp"]
        if n["alpn"]:
            tls["alpn"] = n["alpn"]
        stream["tlsSettings"] = tls
    if net == "ws":
        stream["wsSettings"] = {"path": n["path"] or "/", "host": n["host"]}
    elif net == "grpc":
        stream["grpcSettings"] = {"serviceName": n["service_name"]}
    elif net == "httpupgrade":
        stream["httpupgradeSettings"] = {"path": n["path"] or "/", "host": n["host"]}
    elif net in ("xhttp", "splithttp"):
        stream["network"] = "xhttp"
        stream["xhttpSettings"] = {"path": n["path"] or "/", "host": n["host"], "mode": n["mode"] or "auto"}
    return {"tag": "proxy", "protocol": n["proto"], "settings": settings, "streamSettings": stream}


def to_xray(nodes: list[Node]) -> str:
    configs = []
    for n in nodes:
        configs.append({
            "remarks": n["name"],
            "log": {"loglevel": "warning"},
            "dns": {"servers": ["https://1.1.1.1/dns-query"]},
            "inbounds": [
                {"tag": "socks", "listen": "127.0.0.1", "port": 10808, "protocol": "socks",
                 "settings": {"udp": True},
                 "sniffing": {"enabled": True, "destOverride": ["http", "tls", "quic"], "routeOnly": True}},
            ],
            "outbounds": [_xray_outbound(n),
                          {"tag": "direct", "protocol": "freedom"},
                          {"tag": "block", "protocol": "blackhole"}],
            "routing": {"domainStrategy": "AsIs", "rules": [
                {"type": "field", "ip": ["geoip:private"], "outboundTag": "direct"}]},
        })
    return json.dumps(configs, ensure_ascii=False, indent=2)


CONVERTERS = {
    "raw": to_raw,
    "b64": to_base64,
    "clash": to_clash,
    "singbox": to_singbox,
    "xray": to_xray,
}
