"""Telegram-бот для выдачи VPN-доступа через панель 3x-ui.

Пользователь:  /start -> «Получить VPN» -> заявка -> (одобрение админом) -> ссылка + QR
Админ:         кнопки «Одобрить / Отказать» в заявке + команды /admin
"""

import asyncio
import html
import json
import logging
import os
import time
from datetime import datetime
from io import BytesIO
from pathlib import Path
from zoneinfo import ZoneInfo

import qrcode
from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.types import (BufferedInputFile, CallbackQuery, InlineKeyboardButton,
                           InlineKeyboardMarkup, KeyboardButton, Message,
                           ReplyKeyboardMarkup)
from dotenv import load_dotenv

from subserver import (EmptySubscription, Links, SubSource, public_host_of,
                       start_server)
from xui import XUI, XUIAuthError, XUIError

# ================== настройки из .env ==================

load_dotenv(Path(__file__).with_name(".env"))


def env(name, default=None, required=False):
    value = os.getenv(name, default)
    if required and not value:
        raise SystemExit(f"В файле .env не заполнено {name}")
    return value


BOT_TOKEN = env("BOT_TOKEN", required=True)
ADMIN_IDS = {int(x) for x in env("ADMIN_IDS", required=True).replace(" ", "").split(",") if x}
PANEL_URL = env("PANEL_URL", required=True)
PANEL_API_TOKEN = env("PANEL_API_TOKEN", required=True)
PANEL_VERIFY_SSL = env("PANEL_VERIFY_SSL", "false").lower() == "true"
INBOUND_IDS = [int(x) for x in env("INBOUND_IDS", "2").replace(" ", "").split(",") if x]
SUB_URL = env("SUB_URL", required=True).rstrip("/") + "/"
ACCESS_MODE = env("ACCESS_MODE", "approve").lower()  # approve | open
TRIAL_DAYS = int(env("TRIAL_DAYS", "3"))
DEFAULT_DAYS = int(env("DEFAULT_DAYS", "30"))
# Сроки подписки (в днях), которые можно выбрать в боте
PLANS = [int(x) for x in env("PLANS", "7,21,30,90,180,365").replace(" ", "").split(",") if x]
LIMIT_IP = int(env("LIMIT_IP", "3"))
TRAFFIC_GB = float(env("TRAFFIC_GB", "0"))
TG_PROXY = env("TG_PROXY", "")
SUPPORT_CONTACT = env("SUPPORT_CONTACT", "")
SERVICE_NAME = env("SERVICE_NAME", "VPN")
TZ = ZoneInfo(env("TIMEZONE", "Europe/Moscow"))

# ----- форматы подписок -----
# Откуда бот сам скачивает подписку (по умолчанию — тот же SUB_URL)
SUB_FETCH_URL = env("SUB_FETCH_URL", "") or SUB_URL
# Публичный адрес встроенного сервера подписок (пусто — сервер выключен, форматы выдаются файлами)
SUB_SERVER_PUBLIC_URL = env("SUB_SERVER_PUBLIC_URL", "")
SUB_SERVER_LISTEN = env("SUB_SERVER_LISTEN", "0.0.0.0:2097")
SUB_SERVER_CERT = env("SUB_SERVER_CERT", "")
SUB_SERVER_KEY = env("SUB_SERVER_KEY", "")
# Если в панели включены свои JSON/Clash-подписки — можно указать их начало (необязательно)
SUB_JSON_URL = env("SUB_JSON_URL", "")
SUB_CLASH_URL = env("SUB_CLASH_URL", "")

DATA_FILE = Path(__file__).with_name("data.json")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("vpnbot")

# ================== маленькое хранилище (заявки, напоминания) ==================


class Store:
    def __init__(self, path: Path):
        self.path = path
        self.data = {"pending": {}, "notified": {}}
        if path.exists():
            try:
                self.data.update(json.loads(path.read_text("utf-8")))
            except ValueError:
                log.warning("data.json повреждён, начинаю с пустого")

    def save(self):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), "utf-8")
        tmp.replace(self.path)

    @property
    def pending(self) -> dict:
        return self.data["pending"]

    @property
    def notified(self) -> dict:
        return self.data["notified"]


store = Store(DATA_FILE)
xui = XUI(PANEL_URL, PANEL_API_TOKEN, verify_ssl=PANEL_VERIFY_SSL)
sub_source = SubSource(SUB_FETCH_URL, public_host_of(SUB_URL), verify_ssl=False)
links = Links(SUB_URL, SUB_SERVER_PUBLIC_URL, SUB_CLASH_URL, SUB_JSON_URL, name=SERVICE_NAME)
router = Router()

# ================== тексты и кнопки ==================

BTN_GET = "🔑 Получить VPN"
BTN_STATUS = "📊 Мой статус"
BTN_HELP = "📖 Инструкция"
BTN_SUPPORT = "🆘 Поддержка"
BTN_FORMATS = "📥 Форматы подписки"
BTN_EXTEND = "🔄 Продлить"

MAIN_KB = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text=BTN_GET), KeyboardButton(text=BTN_STATUS)],
              [KeyboardButton(text=BTN_EXTEND), KeyboardButton(text=BTN_FORMATS)],
              [KeyboardButton(text=BTN_HELP), KeyboardButton(text=BTN_SUPPORT)]],
    resize_keyboard=True,
)

# Сервисы (приложения), под которые можно получить подписку.
# ключ: (кнопка, формат подписки, deep link из subserver.DEEP_LINKS или None, платформы, как добавить)
SERVICES = {
    "happ": ("📱 Happ", "b64", "happ", "iPhone, Android, Windows, macOS",
             "«+» → «Вставить из буфера обмена»"),
    "v2rayng": ("🤖 v2rayNG", "b64", "v2rayng", "Android",
                "«+» → «Импорт из буфера обмена» → обновите подписку"),
    "v2rayn": ("🖥 v2rayN", "b64", None, "Windows, macOS, Linux",
               "«Подписки» → «Настройки подписки» → «Добавить» → вставьте адрес"),
    "streisand": ("🍏 Streisand", "b64", "streisand", "iPhone, Mac",
                  "«+» → «Добавить подписку»"),
    "v2raytun": ("🌀 v2RayTun", "b64", "v2raytun", "iPhone, Android, Windows",
                 "«+» → «Импорт из буфера обмена»"),
    "hiddify": ("🟣 Hiddify", "b64", "hiddify", "все платформы",
                "«+» → «Добавить из буфера обмена»"),
    "shadowrocket": ("🚀 Shadowrocket", "b64", None, "iPhone",
                     "«+» → тип «Subscribe» → вставьте адрес"),
    "karing": ("🧭 Karing", "b64", "karing", "все платформы",
               "«+» → «Добавить профиль» → вставьте адрес"),
    "clash": ("🐱 Clash / Mihomo", "clash", "clash",
              "Clash Verge Rev, FlClash, Clash Meta for Android",
              "«Профили» → вставьте адрес → «Импорт»"),
    "singbox": ("📦 sing-box", "singbox", "singbox", "SFI (iPhone), SFA (Android), SFM (Mac)",
                "«Profiles» → «New Profile» → тип «Remote» → вставьте адрес"),
    "xray": ("⚙️ Xray JSON", "xray", None, "v2rayN, v2rayNG, Happ (полный JSON-конфиг)",
             "добавьте адрес как обычную подписку"),
    "raw": ("🔗 Ключи vless://", "raw", None, "любое приложение, ручное добавление",
            "скопируйте ключ и вставьте в приложение"),
}

FORMAT_NAMES = {"b64": "обычная (base64)", "clash": "Clash YAML", "singbox": "sing-box JSON",
                "xray": "Xray JSON", "raw": "ключи vless://"}
FILE_EXT = {"b64": "txt", "clash": "yaml", "singbox": "json", "xray": "json", "raw": "txt"}


def plan_label(days: int) -> str:
    """7 -> «7 дней», 30 -> «1 месяц», 365 -> «1 год» и т.д."""
    if days % 365 == 0:
        n, forms = days // 365, ("год", "года", "лет")
    elif days % 30 == 0:
        n, forms = days // 30, ("месяц", "месяца", "месяцев")
    else:
        n, forms = days, ("день", "дня", "дней")
    if n % 10 == 1 and n % 100 != 11:
        word = forms[0]
    elif 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        word = forms[1]
    else:
        word = forms[2]
    return f"{n} {word}"


def plans_kb(prefix: str) -> InlineKeyboardMarkup:
    """Кнопки выбора срока: 2 в ряд, callback «prefix:дни»."""
    btns = [InlineKeyboardButton(text=f"📅 {plan_label(d)}", callback_data=f"{prefix}:{d}") for d in PLANS]
    return InlineKeyboardMarkup(inline_keyboard=[btns[i:i + 2] for i in range(0, len(btns), 2)])


def approve_kb(uid: int, days: int) -> InlineKeyboardMarkup:
    """Клавиатура заявки для админа: одобрить выбранный срок, другой срок или отказать."""
    rows = [[InlineKeyboardButton(text=f"✅ Выдать {plan_label(days)}", callback_data=f"ok:{uid}:{days}")]]
    others = [InlineKeyboardButton(text=plan_label(d), callback_data=f"ok:{uid}:{d}") for d in PLANS if d != days]
    rows += [others[i:i + 3] for i in range(0, len(others), 3)]
    rows.append([InlineKeyboardButton(text="❌ Отказать", callback_data=f"no:{uid}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def formats_kb() -> InlineKeyboardMarkup:
    items = list(SERVICES.items())
    rows = [[InlineKeyboardButton(text=v[0], callback_data=f"fmt:{k}") for k, v in items[i:i + 2]]
            for i in range(0, len(items), 2)]
    return InlineKeyboardMarkup(inline_keyboard=rows)


FORMATS_TEXT = ("<b>Выберите приложение</b>, в которое хотите добавить VPN — "
                "бот выдаст подписку в подходящем формате.")

HELP_TEXT = (
    "<b>Как подключиться</b>\n\n"
    "1. Установите приложение <b>Happ</b> (App Store / Google Play / есть для Windows и macOS).\n"
    "2. Скопируйте вашу ссылку (нажмите на неё — она скопируется).\n"
    "3. Откройте Happ → «+» → «Вставить из буфера обмена» "
    "(или отсканируйте QR-код).\n"
    "4. Нажмите кнопку подключения.\n\n"
    "<b>iPhone:</b> если в Safari не открываются сайты, выключите "
    "«Настройки → [ваше имя] → iCloud → Частный узел».\n\n"
    "Ссылка личная — не передавайте её другим людям."
)


def email_for(uid: int) -> str:
    return f"tg{uid}"


def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS


def fmt_bytes(n) -> str:
    n = float(n or 0)
    for unit in ("Б", "КБ", "МБ", "ГБ", "ТБ"):
        if n < 1024 or unit == "ТБ":
            return f"{n:.1f} {unit}" if unit != "Б" else f"{int(n)} {unit}"
        n /= 1024


def fmt_expiry(ms) -> str:
    ms = int(ms or 0)
    if ms == 0:
        return "бессрочно"
    if ms < 0:
        return f"{abs(ms) // 86400000} дн. с первого подключения"
    return datetime.fromtimestamp(ms / 1000, TZ).strftime("%d.%m.%Y %H:%M")


def sub_link(client: dict) -> str:
    return SUB_URL + str(client.get("subId", ""))


def qr_png(text: str) -> bytes:
    img = qrcode.make(text, box_size=8, border=2)
    buf = BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def user_label(u) -> str:
    name = html.escape(u.get("name") or "без имени")
    uname = f" @{html.escape(u['username'])}" if u.get("username") else ""
    return f"{name}{uname} (<code>{u['id']}</code>)"


async def send_access(bot: Bot, chat_id: int, client: dict, title: str):
    link = sub_link(client)
    caption = (
        f"{title}\n\n"
        f"Ваша ссылка-подписка (нажмите, чтобы скопировать):\n<code>{html.escape(link)}</code>\n\n"
        f"Действует до: <b>{fmt_expiry(client.get('expiryTime'))}</b>\n\n"
        f"Инструкция — кнопка «{BTN_HELP}»."
    )
    await bot.send_photo(chat_id, BufferedInputFile(qr_png(link), "vpn.png"),
                         caption=caption, reply_markup=MAIN_KB)
    await bot.send_message(chat_id, "Пользуетесь другим приложением? " + FORMATS_TEXT,
                           reply_markup=formats_kb())


async def notify_admins(bot: Bot, text: str, kb=None):
    for aid in ADMIN_IDS:
        try:
            await bot.send_message(aid, text, reply_markup=kb)
        except Exception as e:  # админ мог не запускать бота
            log.warning("Не смог написать админу %s: %s", aid, e)


async def create_or_extend(bot: Bot, uid: int, days: int, comment: str = "") -> tuple[dict, bool]:
    """Создать клиента или продлить существующего. Возвращает (клиент, был_ли_новым)."""
    email = email_for(uid)
    existing = await xui.get_client(email)
    if existing:
        return await xui.extend(email, days), False
    client = await xui.add_client(email, INBOUND_IDS, days, LIMIT_IP, TRAFFIC_GB, comment)
    return client, True


# ================== пользовательская часть ==================


@router.message(CommandStart())
async def cmd_start(m: Message):
    await m.answer(
        f"Привет, {html.escape(m.from_user.first_name or '')}! 👋\n\n"
        f"Это бот <b>{html.escape(SERVICE_NAME)}</b>. "
        f"Нажмите «{BTN_GET}», чтобы получить доступ.",
        reply_markup=MAIN_KB,
    )


@router.message(F.text == BTN_GET)
async def on_get(m: Message, bot: Bot):
    uid = m.from_user.id
    try:
        client = await xui.get_client(email_for(uid))
    except XUIError as e:
        log.error("get_client: %s", e)
        return await m.answer("Сервис временно недоступен, попробуйте позже.")

    if client:
        exp = int(client.get("expiryTime") or 0)
        if not client.get("enable", True) or (exp > 0 and exp < time.time() * 1000):
            return await m.answer("Ваш доступ закончился или отключён. "
                                  f"Для продления нажмите «{BTN_EXTEND}».")
        return await send_access(bot, uid, client, "Ваш доступ уже активен ✅")

    u = {"id": uid, "name": m.from_user.full_name, "username": m.from_user.username}

    if ACCESS_MODE == "open":
        try:
            client, _ = await create_or_extend(bot, uid, TRIAL_DAYS, comment=u.get("username") or u["name"])
        except XUIError as e:
            log.error("add_client: %s", e)
            return await m.answer("Не получилось выдать доступ, попробуйте позже.")
        await send_access(bot, uid, client, f"Пробный доступ на {TRIAL_DAYS} дн. выдан ✅")
        return await notify_admins(bot, f"🆕 Новый пользователь (пробный): {user_label(u)}")

    if str(uid) in store.pending:
        return await m.answer("Ваша заявка уже отправлена, ожидайте ответа ⏳")

    await m.answer("<b>Выберите срок подписки:</b>", reply_markup=plans_kb("req"))


@router.message(F.text == BTN_EXTEND)
async def on_extend(m: Message):
    try:
        client = await xui.get_client(email_for(m.from_user.id))
    except XUIError:
        return await m.answer("Сервис временно недоступен, попробуйте позже.")
    if not client:
        return await m.answer(f"У вас пока нет доступа. Нажмите «{BTN_GET}».")
    await m.answer(f"Сейчас доступ действует до: <b>{fmt_expiry(client.get('expiryTime'))}</b>\n\n"
                   "<b>На сколько продлить?</b>", reply_markup=plans_kb("ext"))


@router.callback_query(F.data.startswith("req:") | F.data.startswith("ext:"))
async def on_plan_chosen(c: CallbackQuery, bot: Bot):
    kind, days = c.data.split(":")
    days = int(days) if days.isdigit() else 0
    if days not in PLANS:
        return await c.answer("Такого срока нет", show_alert=True)
    uid = c.from_user.id
    if str(uid) in store.pending:
        return await c.answer("Ваша заявка уже отправлена, ожидайте ответа ⏳", show_alert=True)
    u = {"id": uid, "name": c.from_user.full_name, "username": c.from_user.username}
    store.pending[str(uid)] = {**u, "at": int(time.time()), "days": days, "kind": kind}
    store.save()
    title = "🔄 Заявка на продление" if kind == "ext" else "📝 Заявка на доступ"
    await notify_admins(bot, f"{title}: {user_label(u)}\nСрок: <b>{plan_label(days)}</b>",
                        approve_kb(uid, days))
    await c.message.edit_text(f"Заявка на <b>{plan_label(days)}</b> отправлена ✅\n"
                              "Как только её одобрят, бот пришлёт вам ссылку.")
    await c.answer()


@router.message(F.text == BTN_STATUS)
async def on_status(m: Message):
    email = email_for(m.from_user.id)
    try:
        client = await xui.get_client(email)
        traffic = await xui.get_traffic(email) if client else {}
    except XUIError:
        return await m.answer("Сервис временно недоступен, попробуйте позже.")
    if not client:
        return await m.answer(f"У вас пока нет доступа. Нажмите «{BTN_GET}».")
    used = int(traffic.get("up") or 0) + int(traffic.get("down") or 0)
    limit = int(client.get("totalGB") or 0)
    exp = int(client.get("expiryTime") or 0)
    active = client.get("enable", True) and not (exp > 0 and exp < time.time() * 1000)
    await m.answer(
        f"<b>Статус:</b> {'активен ✅' if active else 'не активен ❌'}\n"
        f"<b>Действует до:</b> {fmt_expiry(exp)}\n"
        f"<b>Трафик:</b> {fmt_bytes(used)} из {fmt_bytes(limit) if limit else '∞'}\n\n"
        f"Ссылка: <code>{html.escape(sub_link(client))}</code>"
    )


async def active_client(uid: int):
    """Клиент пользователя, если доступ есть и действует, иначе текст причины."""
    try:
        client = await xui.get_client(email_for(uid))
    except XUIError:
        return None, "Сервис временно недоступен, попробуйте позже."
    if not client:
        return None, f"У вас пока нет доступа. Нажмите «{BTN_GET}»."
    exp = int(client.get("expiryTime") or 0)
    if not client.get("enable", True) or (exp > 0 and exp < time.time() * 1000):
        return None, f"Ваш доступ закончился или отключён. Для продления нажмите «{BTN_EXTEND}»."
    return client, ""


@router.message(F.text == BTN_FORMATS)
async def on_formats(m: Message):
    client, why = await active_client(m.from_user.id)
    if not client:
        return await m.answer(why)
    await m.answer(FORMATS_TEXT, reply_markup=formats_kb())


@router.callback_query(F.data == "fmts")
async def on_formats_back(c: CallbackQuery):
    await c.message.edit_text(FORMATS_TEXT, reply_markup=formats_kb())
    await c.answer()


@router.callback_query(F.data.startswith("fmt:"))
async def on_format(c: CallbackQuery):
    key = c.data.split(":", 1)[1]
    if key not in SERVICES:
        return await c.answer()
    client, why = await active_client(c.from_user.id)
    if not client:
        return await c.answer(why, show_alert=True)
    title, fmt, app, platforms, how = SERVICES[key]
    sub_id = str(client.get("subId", ""))
    url = links.sub_url(fmt, sub_id)

    text = [f"<b>{title}</b>", f"Подходит для: {html.escape(platforms)}",
            f"Формат: {FORMAT_NAMES[fmt]}", ""]
    if fmt == "raw":
        try:
            raw, _ = await sub_source.render("raw", sub_id, SERVICE_NAME)
        except Exception as e:
            log.warning("raw для %s: %s", sub_id, e)
            return await c.answer("Не удалось получить ключи, попробуйте позже.", show_alert=True)
        keys = [k for k in raw.splitlines() if k.strip()]
        text.append("Нажмите на ключ, чтобы скопировать:")
        text += [f"<code>{html.escape(k)}</code>" for k in keys[:5]]
        text.append("\nКлючи не обновляются сами. Если сервер поменяется — получите их заново.")
    elif url:
        text += ["Адрес подписки (нажмите, чтобы скопировать):", f"<code>{html.escape(url)}</code>",
                 "", f"Как добавить: {html.escape(how)}."]
    else:
        text += ["Для этого формата бот пришлёт файл — импортируйте его в приложение.",
                 "Файл не обновляется сам: при изменениях скачайте его заново."]

    rows = []
    open_url = links.open_url(app, sub_id) if app and url else ""
    if open_url:
        rows.append([InlineKeyboardButton(text="📲 Открыть в приложении", url=open_url)])
    if fmt != "b64":
        rows.append([InlineKeyboardButton(text="📄 Скачать файл", callback_data=f"file:{key}")])
    rows.append([InlineKeyboardButton(text="⬅️ Другое приложение", callback_data="fmts")])
    await c.message.edit_text("\n".join(text), reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
                              disable_web_page_preview=True)
    await c.answer()


@router.callback_query(F.data.startswith("file:"))
async def on_format_file(c: CallbackQuery, bot: Bot):
    key = c.data.split(":", 1)[1]
    if key not in SERVICES:
        return await c.answer()
    client, why = await active_client(c.from_user.id)
    if not client:
        return await c.answer(why, show_alert=True)
    fmt = SERVICES[key][1]
    try:
        content, _ = await sub_source.render(fmt, str(client.get("subId", "")), SERVICE_NAME)
    except EmptySubscription:
        return await c.answer("В подписке нет серверов. Напишите в поддержку.", show_alert=True)
    except Exception as e:
        log.warning("Файл %s: %s", fmt, e)
        return await c.answer("Не удалось собрать файл, попробуйте позже.", show_alert=True)
    filename = f"{SERVICE_NAME}-{fmt}.{FILE_EXT[fmt]}"
    await bot.send_document(c.from_user.id, BufferedInputFile(content.encode("utf-8"), filename),
                            caption=f"{SERVICES[key][0]}: импортируйте этот файл в приложение.")
    await c.answer("Файл отправлен")


@router.message(F.text == BTN_HELP)
async def on_help(m: Message):
    await m.answer(HELP_TEXT)


@router.message(F.text == BTN_SUPPORT)
async def on_support(m: Message, bot: Bot):
    if SUPPORT_CONTACT:
        return await m.answer(f"Напишите в поддержку: {html.escape(SUPPORT_CONTACT)}")
    await m.answer("Опишите проблему одним сообщением — я передам её администратору.")


# ================== решения админа по заявкам ==================


@router.callback_query(F.data.startswith("ok:"))
async def on_approve(c: CallbackQuery, bot: Bot):
    if not is_admin(c.from_user.id):
        return await c.answer("Нет доступа", show_alert=True)
    _, uid, days = c.data.split(":")
    uid, days = int(uid), int(days)
    u = store.pending.get(str(uid), {"id": uid})
    try:
        client, is_new = await create_or_extend(bot, uid, days,
                                                comment=u.get("username") or u.get("name") or "")
    except XUIError as e:
        return await c.answer(f"Ошибка панели: {e}"[:190], show_alert=True)
    store.pending.pop(str(uid), None)
    store.save()
    title = (f"Доступ на {plan_label(days)} выдан ✅" if is_new
             else f"Доступ продлён на {plan_label(days)} ✅")
    try:
        await send_access(bot, uid, client, title)
    except Exception as e:
        log.warning("Не смог отправить ссылку %s: %s", uid, e)
    await c.message.edit_text(f"{c.message.html_text}\n\n✅ Одобрено: {plan_label(days)} "
                              f"(до {fmt_expiry(client.get('expiryTime'))})")
    await c.answer("Готово")


@router.callback_query(F.data.startswith("no:"))
async def on_reject(c: CallbackQuery, bot: Bot):
    if not is_admin(c.from_user.id):
        return await c.answer("Нет доступа", show_alert=True)
    uid = int(c.data.split(":")[1])
    store.pending.pop(str(uid), None)
    store.save()
    try:
        await bot.send_message(uid, "К сожалению, заявка отклонена.")
    except Exception:
        pass
    await c.message.edit_text(f"{c.message.html_text}\n\n❌ Отклонено")
    await c.answer("Отклонено")


# ================== команды админа ==================

ADMIN_HELP = (
    "<b>Команды администратора</b>\n\n"
    "/add <code>ID дни</code> — выдать или продлить доступ\n"
    "/extend <code>ID дни</code> — продлить\n"
    "/off <code>ID</code> — отключить\n"
    "/on <code>ID</code> — включить\n"
    "/del <code>ID</code> — удалить клиента\n"
    "/info <code>ID</code> — информация о клиенте\n"
    "/users — список клиентов бота\n"
    "/pending — заявки в ожидании\n"
    "/formats <code>ID</code> — ссылки на подписку во всех форматах\n\n"
    "ID — числовой Telegram ID пользователя (есть в каждой заявке)."
)


def parse_args(cmd: CommandObject, n: int):
    parts = (cmd.args or "").split()
    if len(parts) < n or not all(p.lstrip("-").isdigit() for p in parts[:n]):
        return None
    return [int(p) for p in parts[:n]]


@router.message(Command("admin"))
async def cmd_admin(m: Message):
    if is_admin(m.from_user.id):
        await m.answer(ADMIN_HELP)


@router.message(Command("add", "extend"))
async def cmd_add(m: Message, command: CommandObject, bot: Bot):
    if not is_admin(m.from_user.id):
        return
    args = parse_args(command, 2)
    if not args:
        return await m.answer(f"Формат: /{command.command} ID дни")
    uid, days = args
    try:
        if command.command == "extend":
            client, is_new = await xui.extend(email_for(uid), days), False
        else:
            client, is_new = await create_or_extend(bot, uid, days)
    except XUIError as e:
        return await m.answer(f"Ошибка: {html.escape(str(e))}")
    store.pending.pop(str(uid), None)
    store.save()
    await m.answer(f"{'Создан' if is_new else 'Продлён'} tg{uid}, до {fmt_expiry(client.get('expiryTime'))}")
    try:
        title = (f"Доступ на {plan_label(days)} выдан ✅" if is_new
                 else f"Доступ продлён на {plan_label(days)} ✅")
        await send_access(bot, uid, client, title)
    except Exception as e:
        await m.answer(f"Пользователю не отправилось (он не запускал бота?): {html.escape(str(e))}")


@router.message(Command("off", "on"))
async def cmd_onoff(m: Message, command: CommandObject):
    if not is_admin(m.from_user.id):
        return
    args = parse_args(command, 1)
    if not args:
        return await m.answer(f"Формат: /{command.command} ID")
    try:
        await xui.set_enable(email_for(args[0]), command.command == "on")
    except XUIError as e:
        return await m.answer(f"Ошибка: {html.escape(str(e))}")
    await m.answer(f"tg{args[0]} {'включён ✅' if command.command == 'on' else 'отключён ⛔'}")


@router.message(Command("del"))
async def cmd_del(m: Message, command: CommandObject):
    if not is_admin(m.from_user.id):
        return
    args = parse_args(command, 1)
    if not args:
        return await m.answer("Формат: /del ID")
    try:
        await xui.delete_client(email_for(args[0]))
    except XUIError as e:
        return await m.answer(f"Ошибка: {html.escape(str(e))}")
    await m.answer(f"tg{args[0]} удалён 🗑")


@router.message(Command("info"))
async def cmd_info(m: Message, command: CommandObject):
    if not is_admin(m.from_user.id):
        return
    args = parse_args(command, 1)
    if not args:
        return await m.answer("Формат: /info ID")
    email = email_for(args[0])
    try:
        client = await xui.get_client(email)
        traffic = await xui.get_traffic(email) if client else {}
    except XUIError as e:
        return await m.answer(f"Ошибка: {html.escape(str(e))}")
    if not client:
        return await m.answer("Такого клиента нет")
    used = int(traffic.get("up") or 0) + int(traffic.get("down") or 0)
    await m.answer(
        f"<b>{email}</b> ({html.escape(str(client.get('comment') or ''))})\n"
        f"Включён: {'да' if client.get('enable', True) else 'нет'}\n"
        f"До: {fmt_expiry(client.get('expiryTime'))}\n"
        f"Трафик: {fmt_bytes(used)}\n"
        f"Ссылка: <code>{html.escape(sub_link(client))}</code>"
    )


@router.message(Command("users"))
async def cmd_users(m: Message):
    if not is_admin(m.from_user.id):
        return
    try:
        clients = await xui.list_clients()
    except XUIError as e:
        return await m.answer(f"Ошибка: {html.escape(str(e))}")
    bot_clients = [c for c in clients if str(c.get("email", "")).startswith("tg")]
    if not bot_clients:
        return await m.answer("Клиентов, выданных ботом, пока нет.")
    lines = [f"Всего клиентов бота: {len(bot_clients)}\n"]
    for c in bot_clients[:60]:
        mark = "✅" if c.get("enable", True) else "⛔"
        lines.append(f"{mark} <code>{c['email'][2:]}</code> {html.escape(str(c.get('comment') or ''))}"
                     f" — до {fmt_expiry(c.get('expiryTime'))}")
    if len(bot_clients) > 60:
        lines.append(f"…и ещё {len(bot_clients) - 60}")
    await m.answer("\n".join(lines))


@router.message(Command("formats"))
async def cmd_formats(m: Message, command: CommandObject):
    if not is_admin(m.from_user.id):
        return
    args = parse_args(command, 1)
    if not args:
        return await m.answer("Формат: /formats ID")
    try:
        client = await xui.get_client(email_for(args[0]))
    except XUIError as e:
        return await m.answer(f"Ошибка: {html.escape(str(e))}")
    if not client:
        return await m.answer("Такого клиента нет")
    sub_id = str(client.get("subId", ""))
    lines = [f"<b>Подписки tg{args[0]}</b>"]
    for fmt, title in FORMAT_NAMES.items():
        url = links.sub_url(fmt, sub_id)
        lines.append(f"{title}: <code>{html.escape(url)}</code>" if url else f"{title}: только файлом")
    await m.answer("\n".join(lines), disable_web_page_preview=True)


@router.message(Command("pending"))
async def cmd_pending(m: Message):
    if not is_admin(m.from_user.id):
        return
    if not store.pending:
        return await m.answer("Заявок нет.")
    await m.answer("\n".join(f"• {user_label(u)}" for u in store.pending.values()))


# Любое другое сообщение от пользователя — пересылаем админам как обращение в поддержку
@router.message(F.text & ~F.text.startswith("/"))
async def on_other(m: Message, bot: Bot):
    if is_admin(m.from_user.id):
        return await m.answer("Команды администратора: /admin")
    u = {"id": m.from_user.id, "name": m.from_user.full_name, "username": m.from_user.username}
    await notify_admins(bot, f"💬 Сообщение от {user_label(u)}:\n\n{html.escape(m.text)}")
    await m.answer("Сообщение передано администратору ✅", reply_markup=MAIN_KB)


# ================== напоминания об окончании ==================


async def reminder_loop(bot: Bot):
    while True:
        try:
            now = time.time() * 1000
            for c in await xui.list_clients():
                email = str(c.get("email", ""))
                exp = int(c.get("expiryTime") or 0)
                if not email.startswith("tg") or exp <= 0 or not c.get("enable", True):
                    continue
                if 0 < exp - now < 86400 * 1000 and store.notified.get(email) != exp:
                    try:
                        await bot.send_message(
                            int(email[2:]),
                            f"⏰ Ваш доступ к {html.escape(SERVICE_NAME)} закончится "
                            f"{fmt_expiry(exp)}. Для продления нажмите «{BTN_EXTEND}».")
                    except Exception as e:
                        log.warning("Напоминание %s не отправлено: %s", email, e)
                    store.notified[email] = exp
                    store.save()
        except XUIAuthError as e:
            log.error("Напоминания: %s", e)
        except Exception as e:
            log.warning("Напоминания: ошибка %s", e)
        await asyncio.sleep(3600)


# ================== запуск ==================


async def main():
    session = AiohttpSession(proxy=TG_PROXY) if TG_PROXY else None
    bot = Bot(BOT_TOKEN, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)

    # Проверяем связь с панелью сразу при старте, чтобы ошибки были видны
    try:
        await xui.list_clients()
        log.info("Панель 3x-ui: связь есть ✅")
    except XUIError as e:
        log.error("Панель 3x-ui: %s", e)

    runner = None
    if SUB_SERVER_PUBLIC_URL:
        try:
            runner, ctx = await start_server(sub_source, links, SUB_SERVER_LISTEN,
                                             SUB_SERVER_CERT, SUB_SERVER_KEY)
            if ctx:
                asyncio.create_task(cert_reload_loop(ctx))
        except Exception as e:
            log.error("Сервер подписок не запустился: %s (форматы будут выдаваться файлами)", e)
            links.public = ""
    else:
        log.info("Сервер подписок выключен (SUB_SERVER_PUBLIC_URL пуст): форматы выдаются файлами")

    me = await bot.get_me()
    log.info("Бот @%s запущен, режим доступа: %s", me.username, ACCESS_MODE)
    asyncio.create_task(reminder_loop(bot))
    try:
        await dp.start_polling(bot)
    finally:
        await xui.close()
        await sub_source.close()
        if runner:
            await runner.cleanup()


async def cert_reload_loop(ctx):
    """Сертификат панели для IP живёт ~6 дней и сам продлевается — перечитываем его."""
    while True:
        await asyncio.sleep(12 * 3600)
        try:
            ctx.load_cert_chain(SUB_SERVER_CERT, SUB_SERVER_KEY)
            log.info("Сертификат сервера подписок перечитан")
        except Exception as e:
            log.warning("Не смог перечитать сертификат: %s", e)


if __name__ == "__main__":
    asyncio.run(main())
