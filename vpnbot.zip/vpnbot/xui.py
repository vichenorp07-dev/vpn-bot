"""Небольшой клиент для API панели 3x-ui (версия 3.x, новый API /panel/api/clients/...).

Авторизация по API-токену: заголовок "Authorization: Bearer <токен>".
Токен создаётся в самой панели (Настройки панели -> API).
"""

import secrets
import string
import time
import uuid

import httpx

FLOW = "xtls-rprx-vision"
GB = 1024 ** 3


class XUIError(Exception):
    """Панель ответила ошибкой (success = false)."""


class XUIAuthError(XUIError):
    """Неверный токен или нет доступа к API."""


class XUIConnError(XUIError):
    """Панель недоступна (сеть, сбой сервера)."""


def _gen_sub_id(length: int = 16) -> str:
    alphabet = string.ascii_lowercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


class XUI:
    def __init__(self, panel_url: str, token: str, verify_ssl: bool = True, timeout: float = 15):
        # panel_url — полный адрес панели вместе с секретным путём,
        # например https://127.0.0.1:12345/secretpath/
        self.base = panel_url.rstrip("/") + "/panel/api"
        self.http = httpx.AsyncClient(
            verify=verify_ssl,
            timeout=timeout,
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        )

    async def close(self):
        await self.http.aclose()

    async def _req(self, method: str, path: str, json=None):
        try:
            r = await self.http.request(method, self.base + path, json=json)
        except httpx.HTTPError as e:
            raise XUIConnError(f"Нет связи с панелью: {e}") from e
        if r.status_code in (401, 403):
            raise XUIAuthError("Панель отклонила токен (проверь PANEL_API_TOKEN)")
        if r.status_code == 404:
            raise XUIError(f"Адрес API не найден: {path} (проверь PANEL_URL)")
        if r.status_code >= 500:
            raise XUIConnError(f"Сбой панели HTTP {r.status_code}: {r.text[:200]}")
        if r.status_code >= 400:
            raise XUIError(f"Панель ответила HTTP {r.status_code}: {r.text[:200]}")
        try:
            data = r.json()
        except ValueError:
            raise XUIError(f"Панель вернула не JSON: {r.text[:200]}")
        if not data.get("success"):
            raise XUIError(data.get("msg") or "Панель вернула ошибку без описания")
        return data.get("obj")

    # ---------- чтение ----------

    async def get_client(self, email: str):
        """Вернёт словарь клиента или None, если такого нет."""
        try:
            obj = await self._req("GET", f"/clients/get/{email}")
        except (XUIAuthError, XUIConnError):
            raise
        except XUIError:  # клиента с таким email нет
            return None
        if not obj:
            return None
        return obj.get("client", obj) if isinstance(obj, dict) else None

    async def get_traffic(self, email: str) -> dict:
        try:
            obj = await self._req("GET", f"/clients/traffic/{email}")
        except (XUIAuthError, XUIConnError):
            raise
        except XUIError:
            return {}
        return obj or {}

    async def list_clients(self) -> list:
        obj = await self._req("GET", "/clients/list")
        if isinstance(obj, dict):  # на случай, если панель вернёт {items: [...]}
            obj = obj.get("items") or obj.get("clients") or []
        return obj or []

    # ---------- запись ----------

    async def add_client(self, email: str, inbound_ids: list, days: int, limit_ip: int = 0,
                         total_gb: float = 0, comment: str = "") -> dict:
        expiry = int((time.time() + days * 86400) * 1000) if days > 0 else 0
        client = {
            "email": email,
            "id": str(uuid.uuid4()),
            "flow": FLOW,
            "subId": _gen_sub_id(),
            "totalGB": int(total_gb * GB),
            "expiryTime": expiry,
            "limitIp": limit_ip,
            "enable": True,
            "comment": comment,
        }
        await self._req("POST", "/clients/add", {"inboundIds": inbound_ids, "client": client})
        # Берём то, что реально сохранилось в панели
        return await self.get_client(email) or client

    async def update_client(self, email: str, **changes) -> dict:
        client = await self.get_client(email)
        if client is None:
            raise XUIError(f"Клиент {email} не найден")
        client.update(changes)
        await self._req("POST", f"/clients/update/{email}", client)
        return client

    async def extend(self, email: str, days: int) -> dict:
        """Продлить на days дней. Если срок уже истёк — считаем от сегодня."""
        client = await self.get_client(email)
        if client is None:
            raise XUIError(f"Клиент {email} не найден")
        now_ms = int(time.time() * 1000)
        current = int(client.get("expiryTime") or 0)
        if current < 0:  # «старт после первого использования» хранится отрицательным числом
            current = now_ms + abs(current)
        base = max(now_ms, current) if current else now_ms
        return await self.update_client(email, expiryTime=base + days * 86400 * 1000, enable=True)

    async def set_enable(self, email: str, enable: bool) -> dict:
        return await self.update_client(email, enable=enable)

    async def delete_client(self, email: str):
        await self._req("POST", f"/clients/del/{email}")
