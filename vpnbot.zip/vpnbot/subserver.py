"""Сервер подписок в разных форматах + страницы «открыть в приложении».

Бот берёт обычную подписку клиента у панели 3x-ui и на лету переделывает её
в нужный формат. Адреса:

  /c/clash/<subId>     — Clash Meta / Mihomo (YAML)
  /c/singbox/<subId>   — sing-box (JSON)
  /c/xray/<subId>      — Xray JSON
  /c/raw/<subId>       — ссылки vless:// текстом
  /c/b64/<subId>       — обычная подписка (base64)
  /open/<app>/<subId>  — страница, которая открывает приложение и добавляет подписку

Ссылки на подписку автоматически обновляются в приложениях, потому что всегда
отдают актуальные данные из панели.
"""

import html
import json
import logging
import re
import ssl
import time
from urllib.parse import quote, urlparse

import httpx
from aiohttp import web

import subconv

log = logging.getLogger("vpnbot.sub")

SUB_ID_RE = re.compile(r"^[A-Za-z0-9_-]{4,64}$")

# формат -> (Content-Type, расширение файла)
FORMATS = {
    "clash": ("text/yaml; charset=utf-8", "yaml"),
    "singbox": ("application/json; charset=utf-8", "json"),
    "xray": ("application/json; charset=utf-8", "json"),
    "raw": ("text/plain; charset=utf-8", "txt"),
    "b64": ("text/plain; charset=utf-8", "txt"),
}

# Заголовки панели, которые полезно передать приложениям (трафик, срок, название)
PASS_HEADERS = ("subscription-userinfo", "profile-update-interval", "profile-title",
                "support-url", "profile-web-page-url", "announce")


class EmptySubscription(Exception):
    """Подписки с таким subId нет или в ней нет серверов."""


class SubSource:
    """Скачивает обычную подписку у панели (с кешем на 60 секунд)."""

    def __init__(self, panel_sub_url: str, public_host: str, verify_ssl: bool = False):
        self.panel_sub_url = panel_sub_url.rstrip("/") + "/"
        self.public_host = public_host
        self.http = httpx.AsyncClient(verify=verify_ssl, timeout=15, follow_redirects=True)
        self.cache: dict[str, tuple[float, str, dict]] = {}

    async def close(self):
        await self.http.aclose()

    async def fetch(self, sub_id: str) -> tuple[str, dict]:
        if not SUB_ID_RE.match(sub_id):
            raise EmptySubscription(sub_id)
        hit = self.cache.get(sub_id)
        if hit and time.time() - hit[0] < 60:
            return hit[1], hit[2]
        r = await self.http.get(self.panel_sub_url + sub_id)
        if r.status_code != 200 or not r.text.strip():
            raise EmptySubscription(sub_id)
        headers = {k: v for k, v in r.headers.items() if k.lower() in PASS_HEADERS}
        self.cache[sub_id] = (time.time(), r.text, headers)
        return r.text, headers

    async def render(self, fmt: str, sub_id: str, name: str = "VPN") -> tuple[str, dict]:
        body, headers = await self.fetch(sub_id)
        nodes = subconv.parse_subscription(body, self.public_host)
        if not nodes:
            raise EmptySubscription(sub_id)
        if fmt == "clash":
            text = subconv.to_clash(nodes, group=name)
        elif fmt == "singbox":
            text = subconv.to_singbox(nodes, group=name)
        else:
            text = subconv.CONVERTERS[fmt](nodes)
        return text, headers


# ============ ссылки «открыть в приложении» (deep links) ============
# app -> (как построить ссылку, какой формат подписки нужен приложению)

def _enc(u: str) -> str:
    return quote(u, safe="")


DEEP_LINKS = {
    "happ": (lambda u, n: f"happ://add/{u}", "b64"),
    "hiddify": (lambda u, n: f"hiddify://import/{u}#{quote(n)}", "b64"),
    "v2rayng": (lambda u, n: f"v2rayng://install-config?url={_enc(u)}#{quote(n)}", "b64"),
    "streisand": (lambda u, n: f"streisand://import/{u}#{quote(n)}", "b64"),
    "v2raytun": (lambda u, n: f"v2raytun://import/{u}", "b64"),
    "clash": (lambda u, n: f"clash://install-config?url={_enc(u)}&name={quote(n)}", "clash"),
    "singbox": (lambda u, n: f"sing-box://import-remote-profile?url={_enc(u)}#{quote(n)}", "singbox"),
    "karing": (lambda u, n: f"karing://install-config?url={_enc(u)}&name={quote(n)}", "b64"),
}

OPEN_PAGE = """<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title>
<style>
body{{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#111;color:#eee;
margin:0;padding:24px;display:flex;justify-content:center}}
.box{{max-width:420px;width:100%}}
a.btn{{display:block;text-align:center;background:#3b82f6;color:#fff;padding:16px;
border-radius:12px;text-decoration:none;font-size:18px;margin:20px 0}}
textarea{{width:100%;box-sizing:border-box;background:#222;color:#eee;border:1px solid #444;
border-radius:8px;padding:10px;font-size:13px}}
p{{color:#aaa;line-height:1.4}}
</style></head><body><div class="box">
<h2>{title}</h2>
<p>Нажмите кнопку — откроется приложение и добавит подписку.
Если приложение не установлено, сначала установите его.</p>
<a class="btn" href="{deeplink}">📲 Открыть в приложении</a>
<p>Не открылось? Скопируйте ссылку и добавьте её в приложении вручную («+» → «Импорт из буфера»):</p>
<textarea rows="4" readonly onclick="this.select()">{sub_url}</textarea>
</div>
<script>setTimeout(function(){{location.href={deeplink_js};}},300);</script>
</body></html>"""


class Links:
    """Собирает адреса подписок для каждого формата."""

    def __init__(self, panel_sub_url: str, public_url: str = "", clash_url: str = "",
                 json_url: str = "", name: str = "VPN"):
        self.panel = panel_sub_url.rstrip("/") + "/"
        self.public = public_url.rstrip("/")
        self.clash = clash_url.rstrip("/") + "/" if clash_url else ""
        self.json = json_url.rstrip("/") + "/" if json_url else ""
        self.name = name

    @property
    def server_enabled(self) -> bool:
        return bool(self.public)

    def sub_url(self, fmt: str, sub_id: str) -> str:
        """Адрес подписки в формате fmt или "" если такой адрес выдать нельзя (только файл)."""
        if fmt == "b64":
            return self.panel + sub_id
        if fmt == "clash" and self.clash:
            return self.clash + sub_id
        if fmt == "xray" and self.json:
            return self.json + sub_id
        if self.public:
            return f"{self.public}/c/{fmt}/{sub_id}"
        return ""

    def open_url(self, app: str, sub_id: str) -> str:
        if not self.public or app not in DEEP_LINKS:
            return ""
        return f"{self.public}/open/{app}/{sub_id}"


def build_app(source: SubSource, links: Links) -> web.Application:
    async def sub_handler(request: web.Request):
        fmt, sub_id = request.match_info["fmt"], request.match_info["sub_id"]
        if fmt not in FORMATS:
            raise web.HTTPNotFound()
        try:
            text, headers = await source.render(fmt, sub_id, links.name)
        except EmptySubscription:
            raise web.HTTPNotFound()
        except httpx.HTTPError as e:
            log.warning("Панель недоступна: %s", e)
            raise web.HTTPServiceUnavailable()
        ctype, ext = FORMATS[fmt]
        out = dict(headers)
        out.setdefault("profile-update-interval", "12")
        out["Content-Disposition"] = f'attachment; filename="{quote(links.name)}-{fmt}.{ext}"'
        out["Cache-Control"] = "no-store"
        return web.Response(text=text, headers=out, content_type=ctype.split(";")[0], charset="utf-8")

    async def open_handler(request: web.Request):
        app, sub_id = request.match_info["app"], request.match_info["sub_id"]
        if app not in DEEP_LINKS or not SUB_ID_RE.match(sub_id):
            raise web.HTTPNotFound()
        build, fmt = DEEP_LINKS[app]
        sub_url = links.sub_url(fmt, sub_id)
        deeplink = build(sub_url, links.name)
        page = OPEN_PAGE.format(
            title=html.escape(links.name),
            deeplink=html.escape(deeplink, quote=True),
            deeplink_js=json.dumps(deeplink).replace("</", "<\\/"),
            sub_url=html.escape(sub_url),
        )
        return web.Response(text=page, content_type="text/html", charset="utf-8",
                            headers={"Cache-Control": "no-store", "Referrer-Policy": "no-referrer"})

    async def health(_):
        return web.Response(text="ok")

    app = web.Application()
    app.router.add_get("/c/{fmt}/{sub_id}", sub_handler)
    app.router.add_get("/open/{app}/{sub_id}", open_handler)
    app.router.add_get("/health", health)
    return app


def make_ssl_context(cert: str, key: str) -> ssl.SSLContext | None:
    if not cert or not key:
        return None
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.load_cert_chain(cert, key)
    return ctx


async def start_server(source: SubSource, links: Links, listen: str, cert: str = "", key: str = ""):
    """Запускает HTTP(S)-сервер подписок. Возвращает (runner, ssl_context)."""
    host, _, port = listen.rpartition(":")
    ctx = make_ssl_context(cert, key)
    runner = web.AppRunner(build_app(source, links), access_log=None)
    await runner.setup()
    site = web.TCPSite(runner, host or "0.0.0.0", int(port), ssl_context=ctx)
    await site.start()
    log.info("Сервер подписок слушает %s (%s)", listen, "HTTPS" if ctx else "HTTP")
    return runner, ctx


def public_host_of(url: str) -> str:
    return urlparse(url).hostname or ""
